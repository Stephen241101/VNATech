!/bin/bash


BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'  

echo -e "${BLUE}${BOLD}================================WRITE MAC ADRESS ================================${NC}"

echo "Updating MAC address..."

MAC=$1
echo $MAC
A="000000: a5"
B="000006000f21800000"
string=$A$MAC$B
echo $string 
echo $string | xxd -r - MAC

IP=$2
echo $IP

adb connect $IP
adb devices | grep -w "device" > /dev/null
if [ $? -ne 0 ]; then
    echo "ADB no devices. Check your ADB devices."
    exit 1
fi

# Push file MAC vào thư mục /data/
echo "Push file vào /data/ to devices..."
adb root
adb connect $IP
adb push MAC /data/


adb shell << EOF
ethtool -E eth0 magic 0x78A5 offset 0 length 254 < /data/MAC
rm /data/MAC
exit
EOF

# Reboot the device
echo -e "${BLUE}${BOLD}Rebooting the device...${NC}"
adb reboot

# End of script
echo -e "${BLUE}${BOLD}Process write MAC completed successfully!${NC}"






